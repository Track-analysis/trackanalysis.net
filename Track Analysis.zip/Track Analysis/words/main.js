let getP = document.querySelector('.words')
let splitWords = words.split('\n')

for (let i = 0; i < splitWords.length; i++) {
    getP.append(splitWords[i]);
    let br = document.createElement('br');
    getP.appendChild(br);
}
